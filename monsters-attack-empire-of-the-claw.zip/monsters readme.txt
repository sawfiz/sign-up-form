Monsters Attack!.TTF
� 1998 Letters From The Claw

Version A.D. 1937  (Boris Karloff Edition)

My finest effort to date...this is my final version of this font,
dedicated to the late, great Mr. Karloff and to those who love him.

The font does contain some punctuation: !$&,.-+=?
as well as the following dingbats, taken from black-and-white
illustrations advertising those ultra-cool Aurora Famous Monsters
model kits!  If I close my eyes tightly and concentrate, I can
still see the Frankenstein Monster's glow-in-the-dark hands,
can't you?

% - Frankenstein
* - Frankenstein Amok
[ - Creature From Black Lagoon
] - Mummy
^ - Big Frankenstein
_ - Hunchback
` - Dracula
{ - Godzilla
| - Phantom of the Opera
} - King Kong

This font is freeware and may be redistributed wildly, running 
amok through the countryside with a bunch of villagers carrying
torches shrieking at your heels!

For more horror fonts, strange horror comix and
general fear, visit the Empire of The Claw:
http://www.mysite.com/empire

As Boris would say, "MMMMmmmmnnnnaagh!"

The Claw
theclaw@hypercon.com
